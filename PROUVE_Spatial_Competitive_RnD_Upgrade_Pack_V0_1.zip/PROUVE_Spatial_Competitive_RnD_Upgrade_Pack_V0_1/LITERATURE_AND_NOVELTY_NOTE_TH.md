# บันทึกวรรณกรรมและการอ้างความใหม่ (V0.1)

## ประเด็น Phase Arrangement

แนวคิดการนับ lattice points ภายใต้ translation และการเป็น piecewise-constant บน toric arrangement มีวรรณกรรมรองรับอยู่แล้ว จึงห้ามอ้างว่าแนวคิด arrangement ของ phase space เป็นทฤษฎีใหม่โดยตัวมันเอง

แหล่งที่ต้องอ่านเทียบ:

1. Freyer & Hofstätter (2026), *Counting Lattice Points in Translations: Uniqueness and Existence Results*, arXiv:2610.26523v2 — https://arxiv.org/abs/2610.26523
2. Dickerson & Scharstein (1998), *Optimal placement of convex polygons to maximize point containment*, Computational Geometry 11(1), 1–16 — https://doi.org/10.1016/S0925-7721(98)00015-7
3. Wein (2007), *Exact and approximate construction of offset polygons*, Computer-Aided Design 39(6), 518–527 — https://doi.org/10.1016/j.cad.2007.01.010
4. Eisenbrand & Hähnle (2013), *Minimizing the number of lattice points in a translated polygon*, SODA 2013 — https://doi.org/10.1137/1.9781611973105.80 (เป็นปัญหา minimization ที่เกี่ยวข้อง แต่ไม่ใช่ objective maximization ของเรา)

## Contribution ที่ยังอาจพัฒนาได้

คุณค่าที่ต้องทดสอบอาจอยู่ในวิศวกรรมอัลกอริทึมสำหรับ polygon ใช้ได้จริงที่เว้า/มีรู/หลาย component ร่วมกับ crop-lattice constraints, obstacle/setback, uncertainty, certified verification และ evidence report ที่ทำซ้ำได้ ไม่ใช่แค่การสร้าง arrangement

ก่อนประกาศความใหม่ต้องทำ literature search ที่ครอบคลุมกว่านี้และเปรียบเทียบกับวิธีใน computational geometry, lattice-point enumeration, configuration space, mathematical morphology, spatial packing และ agricultural machinery/row-layout planning
