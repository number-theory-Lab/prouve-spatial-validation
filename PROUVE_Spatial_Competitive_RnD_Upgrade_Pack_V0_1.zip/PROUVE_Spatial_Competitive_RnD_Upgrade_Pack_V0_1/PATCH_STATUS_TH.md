# PATCH-01 ถึง PATCH-10 — Prototype Status

| Patch | Prototype behavior | Test status | Engine baseline status |
|---|---|---|---|
| 01 | BF < UB => best-found, not proven optimal | PASS | NOT APPLIED |
| 02 | BF = UB > 0 requires certified UB + verifier PASS before family-optimal claim | PASS | NOT APPLIED |
| 03 | BF > UB => bound conflict / HOLD | PASS | NOT APPLIED |
| 04 | BF = UB = 0 is not a usable planting plan | PASS | NOT APPLIED |
| 05 | Empty point set cannot be VERIFIED_FEASIBLE | PASS | NOT APPLIED |
| 06 | Reject NaN, Infinity, invalid types and invalid counts | PASS | NOT APPLIED |
| 07 | Do not subtract epsilon before ceil; uncertified quotient => estimate only | PASS | NOT APPLIED |
| 08 | Reference checks for concavity, obstacles and self-intersection in defined fixtures | PASS | NOT APPLIED |
| 09 | Explicit boundary inclusion semantics for tested fixture | PASS | NOT APPLIED |
| 10 | Verifier disagreement => HOLD | PASS | NOT APPLIED |

Prototype tests: 22/22 passed (engine research test suite). This does not mean every Patch is a separate test; see test names/log. Original engine files have not been modified or run against original regression fixtures in this package.
