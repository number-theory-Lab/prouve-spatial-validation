# PROUVÉ Spatial — Competitive R&D Upgrade Pack V0.1

**วันที่:** 25 พฤศจิกายน 2569  
**สถานะ:** ชุดวิจัยและต้นแบบแยกจากแอป V0.5.2 Development Copy และ Engine Baseline เดิม  
**ไม่ใช่ Release และไม่ใช่หลักฐานการชนะการแข่งขันหรือการรับรองภาคสนาม**

## วัตถุประสงค์

แพ็กเกจนี้เริ่มยกระดับ PROUVÉ Spatial จากแอปเก็บ/แสดงข้อมูลแปลง ไปสู่ระบบตัดสินใจเชิงพื้นที่ที่ตรวจสอบได้ โดยจัดทำต้นแบบ 3 ส่วน:

1. **Engine safety & reference checks** — ทดลองกติกา PATCH-01 ถึง PATCH-10 และ reference verifier แบบไม่เรียก Shapely ในตัวตรวจสอบตำแหน่งพื้นฐาน
2. **Phase Arrangement research prototype** — สำรวจ candidate phase จาก arrangement ของพื้นที่ใน phase square แทนการตรวจเฉพาะ uniform phase grid สำหรับ orientation ที่กำหนดคงที่
3. **Handoff Adapter** — ตรวจสัญญาข้อมูลจาก app export และ site/crop profile ก่อนอนุญาตส่งต่อเป็น engine case

## สถานะการทดสอบที่รันซ้ำก่อนบรรจุ

| ชุด | ผล | ขอบเขต |
|---|---:|---|
| Engine research prototype | 22/22 PASS | synthetic unit tests สำหรับ patch logic, reference checks, phase arrangement และ BnB helper |
| Handoff Adapter | 13/13 PASS | input schema, CRS, status, reviewer gates และ finite values |
| Phase Arrangement benchmark | 20/20 cases: arrangement count ไม่น้อยกว่า grid 20×20; 3/20 ดีกว่า 1 จุด | synthetic polygons 5 รูป × orientation 4 ค่า; orientation คงที่ |
| Runtime median | 0.0299 s arrangement vs 0.0301 s grid 20×20 | fixture เล็ก; ใกล้เคียงกัน ไม่ใช่หลักฐานว่าเร็วกว่าโดยทั่วไป |
| Orientation BnB exploratory | BF=26, UB=33, gap=7 หลัง 300 nodes | bound ยังหลวมและหยุดตาม node limit; ยังไม่พร้อมใช้ |

**สำคัญ:** 22 tests และ 13 tests เป็นคนละชุดทดสอบและรันในคนละ working directory ไม่ใช่การทดสอบ end-to-end ของระบบที่เชื่อมกันแล้ว

## วิธีรันทดสอบ

ต้องติดตั้ง Python 3.10+ และ dependencies ตามโค้ดที่ใช้ (prototype ต้องการ Shapely 2.x และ NumPy ในส่วน geometry; adapter ใช้ standard library เป็นหลัก)

```bash
cd prototype
python -m unittest -v

cd ../adapter
python -m unittest -v test_handoff_adapter.py
```

Benchmark phase arrangement:

```bash
cd prototype
python run_research_benchmark.py
```

การรัน benchmark ใหม่จะได้ runtime แตกต่างได้ตามเครื่องและโหลดระบบ ผลที่บันทึกใน `prototype_benchmark_results.json` เป็นผลของรอบที่ระบุในรายงาน V0.1 ไม่ควรเขียนทับย้อนหลังโดยไม่สร้าง run ID ใหม่

## ข้อจำกัดและคำเตือน

- **ยังไม่ได้แก้ไฟล์ต้นฉบับ** `geometry_engine_v02.py`, `optimization_engine_v04.py`, `independent_verifier.py` และยังไม่ได้ merge/commit แพตช์เข้า GitHub main หรือเปลี่ยนเว็บแอป
- PATCH-01..10 ในชุดนี้เป็น **isolated implementation prototype** ไม่ใช่หลักฐานว่าแพตช์ถูกนำไปใช้ใน Engine Baseline เดิมแล้ว
- Phase Arrangement มีเหตุผลเชิง combinatorial ว่าค่าการนับเปลี่ยนเป็นช่วง ๆ บน arrangement ของ phase space แต่ implementation ปัจจุบันยังพึ่ง floating-point/Shapely/GEOS ในการสร้าง topology; สถานะคือ `PHASE_ARRANGEMENT_COMPLETE_NUMERICAL_TOPOLOGY_UNVERIFIED` ห้ามเรียกว่า formally exact หรือ certified
- Branch-and-Bound ยังมี gap 7 ใน benchmark สำรวจ จึงพักไว้เป็น research candidate
- Reference verifier ลดการพึ่งไลบรารีเดียวกันในระดับ source code แต่ยังเป็น floating-point computational geometry ไม่ใช่ exact-arithmetic proof หรือ external independent audit
- ไม่มี real farm boundary, real crop profile, field calibration, GNSS reference, agronomist approval หรือ farmer study ในผลการทดสอบชุดนี้
- ตัวอย่างระยะปลูก/ข้อมูลสังเคราะห์ไม่ใช่คำแนะนำทางการเกษตร
- FTS-01 ยังไม่ผ่านการทดลองและไม่ควรนำผลจากแพ็กเกจนี้ไปใช้ตัดสินใจปลูกจริง

## เส้นทางพัฒนาต่อ

1. Freeze baseline และ recover engine sources + original fixtures/dependency environment
2. Apply PATCH-01..10 ใน Engine Branch แยก พร้อม regression และ clean-room rerun
3. ขยาย benchmark phase arrangement, compare กับ exact small-case/reference และทำ robust numeric predicates
4. ปรับปรุง bound ของ orientation BnB หรือยกเลิกหากไม่คุ้ม
5. ทำ pipeline Adapter → Geometry → Optimization → Independent Verifier → Evidence Report
6. จึงค่อยออกแบบ Optimization Results UI และทำ FTS-01 หลังผู้เชี่ยวชาญอนุมัติ crop profile/clearance/uncertainty

## App source snapshot ที่ตรวจในรอบนี้

- Repository: https://github.com/number-theory-Lab/prouve-spatial-validation
- Development site: https://number-theory-lab.github.io/prouve-spatial-validation/
- Commit reviewed: `9169c51f4fa7a5b55a5979c3f16de2cfbe9a7cde`
- `index.html` blob SHA: `2b0341b8d69828de39e8a5ad9a27e4f116a0633b`
- `sw.js` blob SHA: `b06f0a055d461c051aceee277ef09764ff8b0e6d`

## กติกาการกล่าวอ้าง

ไม่อ้างว่า “ใหม่กว่า เร็วกว่า แม่นยำกว่า” โดยไม่มี benchmark ที่ควบคุม input, objective, constraints, hardware/runtime budget และ verifier เดียวกัน/เทียบเคียงกันอย่างเปิดเผย ไม่อ้าง global optimum นอก candidate family ที่พิสูจน์ไว้ และไม่อ้าง field validation จาก synthetic fixtures
