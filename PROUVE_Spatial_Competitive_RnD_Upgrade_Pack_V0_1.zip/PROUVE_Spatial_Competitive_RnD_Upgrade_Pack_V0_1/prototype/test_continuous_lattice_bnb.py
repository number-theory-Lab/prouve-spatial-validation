import math
import random
import unittest

from shapely.geometry import Polygon, box

from continuous_lattice_bnb import (
    _candidate_index_ranges, _node_upper_bound, _count_layout,
    optimize_rectangular_lattice, SearchInputError,
)


class ContinuousLatticeBnbTests(unittest.TestCase):
    def setUp(self):
        self.poly = Polygon([(0,0),(12,0),(12,8),(8,8),(8,5),(4,5),(4,8),(0,8)])
        self.spacing_a = 2.0
        self.spacing_b = 2.5
        self.ranges, self.center = _candidate_index_ranges(self.poly, self.spacing_a, self.spacing_b)

    def test_seed_result_is_feasible_and_bound_dominates(self):
        out = optimize_rectangular_lattice(self.poly, self.spacing_a, self.spacing_b,
                                           max_nodes=150, seed_grid_angle_step=30,
                                           seed_phase_divisions=3)
        self.assertGreaterEqual(out['best_found_count'], 0)
        self.assertGreaterEqual(out['upper_bound_count'], out['best_found_count'])
        self.assertGreaterEqual(out['absolute_gap'], 0)
        self.assertGreater(out['evaluated_layouts'], 0)

    def test_root_upper_bound_dominates_random_parameter_samples(self):
        root_ub = _node_upper_bound(self.poly, (0,180), (0,1), (0,1),
                                    self.spacing_a, self.spacing_b,
                                    self.center, self.ranges)
        rng = random.Random(20261125)
        for _ in range(250):
            theta = rng.random()*180
            pa, pb = rng.random(), rng.random()
            count = _count_layout(self.poly, theta, pa, pb, self.spacing_a,
                                  self.spacing_b, self.center, self.ranges)
            self.assertLessEqual(count, root_ub)

    def test_upper_bound_dominates_dense_small_grid(self):
        root_ub = _node_upper_bound(self.poly, (0,180), (0,1), (0,1),
                                    self.spacing_a, self.spacing_b,
                                    self.center, self.ranges)
        for ti in range(0, 180, 10):
            for ai in range(0, 10):
                for bi in range(0, 10):
                    n = _count_layout(self.poly, ti, ai/10, bi/10,
                                      self.spacing_a, self.spacing_b,
                                      self.center, self.ranges)
                    self.assertLessEqual(n, root_ub)

    def test_invalid_spacing_rejected(self):
        with self.assertRaises(SearchInputError):
            optimize_rectangular_lattice(self.poly, 0, 2)

    def test_empty_geometry_rejected(self):
        with self.assertRaises(SearchInputError):
            optimize_rectangular_lattice(Polygon(), 2, 3)

    def test_rectangle_edge_boundary_is_included(self):
        p = box(0,0,4,4)
        count = _count_layout(p, 0, 0, 0, 2, 2, (2,2), (-3,3,-3,3))
        self.assertGreaterEqual(count, 9)


if __name__ == '__main__':
    unittest.main(verbosity=2)
