#!/usr/bin/env python3
"""PROUVÉ Spatial V0.4 — Optimization & Research Validation.

Searches discrete orientation/phase grids for rectangular, square and triangular
lattices. Results are best-found over the explicitly enumerated search grid,
not automatically a continuous/global optimum. Coordinates are local XY metres.
Requires Shapely >= 2 and NumPy.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import shapely
from shapely.geometry import Polygon

from geometry_engine_v02 import compute_usable_area, GeometryInputError

TAU = 2.0 * math.pi


class OptimizationInputError(ValueError):
    pass


@dataclass(frozen=True)
class LatticeSpec:
    name: str
    family: str
    a_length: float
    b_length: float
    gamma_deg: float
    cell_area: float
    circumradius: float
    angle_period_deg: float
    phases_description: str


def _make_specs(row_spacing: float, in_row_spacing: float) -> dict[str, LatticeSpec]:
    rect_area = row_spacing * in_row_spacing
    square_spacing = math.sqrt(rect_area)
    triangular_spacing = math.sqrt(2.0 * rect_area / math.sqrt(3.0))
    return {
        "rectangular_crop": LatticeSpec(
            "Rectangular crop-row lattice", "rectangular", in_row_spacing,
            row_spacing, 90.0, rect_area,
            0.5 * math.hypot(in_row_spacing, row_spacing), 180.0,
            "two independent fractional phases in [0,1)"
        ),
        "square_equal_density": LatticeSpec(
            "Square lattice (equal nominal area per station)", "square",
            square_spacing, square_spacing, 90.0, square_spacing ** 2,
            square_spacing / math.sqrt(2.0), 90.0,
            "two independent fractional phases in [0,1)"
        ),
        "triangular_equal_density": LatticeSpec(
            "Triangular lattice (equal nominal area per station)", "triangular",
            triangular_spacing, triangular_spacing, 60.0,
            (math.sqrt(3.0) / 2.0) * triangular_spacing ** 2,
            (math.sqrt(3.0) / 2.0) * triangular_spacing, 60.0,
            "two independent fractional phases in [0,1)"
        ),
    }


def _basis(spec: LatticeSpec, theta_deg: float) -> tuple[np.ndarray, np.ndarray]:
    t = math.radians(theta_deg)
    if spec.family in ("rectangular", "square"):
        a = np.array([spec.a_length * math.cos(t), spec.a_length * math.sin(t)])
        b = np.array([-spec.b_length * math.sin(t), spec.b_length * math.cos(t)])
    elif spec.family == "triangular":
        a = spec.a_length * np.array([math.cos(t), math.sin(t)])
        t2 = t + math.radians(60.0)
        b = spec.b_length * np.array([math.cos(t2), math.sin(t2)])
    else:
        raise OptimizationInputError(f"Unknown lattice family: {spec.family}")
    return a, b


def _project_bbox_coefficients(field_bounds: tuple[float, float, float, float],
                               a: np.ndarray, b: np.ndarray) -> tuple[float, float, float, float]:
    minx, miny, maxx, maxy = field_bounds
    corners = np.array([[minx, miny], [minx, maxy], [maxx, miny], [maxx, maxy]], dtype=float)
    matrix = np.column_stack([a, b])
    inv = np.linalg.inv(matrix)
    coeffs = corners @ inv.T
    return (float(coeffs[:, 0].min()), float(coeffs[:, 1].min()),
            float(coeffs[:, 0].max()), float(coeffs[:, 1].max()))


def _candidate_indices(bounds: tuple[float, float, float, float],
                       phase_a: float, phase_b: float) -> tuple[np.ndarray, np.ndarray]:
    amin, bmin, amax, bmax = bounds
    # Add one full index at either end to protect against round-off at envelope edges.
    j0 = math.floor(amin - phase_a) - 1
    j1 = math.ceil(amax - phase_a) + 1
    i0 = math.floor(bmin - phase_b) - 1
    i1 = math.ceil(bmax - phase_b) + 1
    js = np.arange(j0, j1 + 1, dtype=np.int32)
    ii = np.arange(i0, i1 + 1, dtype=np.int32)
    jj_grid, ii_grid = np.meshgrid(js, ii)
    return jj_grid.ravel(), ii_grid.ravel()


def enumerate_layout(usable, field_bounds, spec: LatticeSpec, theta_deg: float,
                     phase_a: float, phase_b: float,
                     include_points: bool = False) -> dict[str, Any]:
    """Count lattice stations covered by usable geometry for one angle/phase."""
    a, b = _basis(spec, theta_deg)
    coeff_bounds = _project_bbox_coefficients(field_bounds, a, b)
    js, ii = _candidate_indices(coeff_bounds, phase_a, phase_b)
    ca = phase_a + js.astype(float)
    cb = phase_b + ii.astype(float)
    xs = ca * a[0] + cb * b[0]
    ys = ca * a[1] + cb * b[1]
    pts = shapely.points(xs, ys)
    mask = np.asarray(shapely.covers(usable, pts), dtype=bool)
    accepted = np.flatnonzero(mask)
    result: dict[str, Any] = {
        "count": int(len(accepted)),
        "theta_deg": float(theta_deg % spec.angle_period_deg),
        "phase_a": float(phase_a % 1.0),
        "phase_b": float(phase_b % 1.0),
        "candidate_count": int(len(xs)),
        "accepted_indices": accepted,
        "accepted_x": xs[accepted],
        "accepted_y": ys[accepted],
        "accepted_j": js[accepted],
        "accepted_i": ii[accepted],
        "a": a,
        "b": b,
    }
    if not include_points:
        result.pop("accepted_indices", None)
        result.pop("accepted_x", None)
        result.pop("accepted_y", None)
        result.pop("accepted_j", None)
        result.pop("accepted_i", None)
        result.pop("a", None)
        result.pop("b", None)
    return result


def _phase_values(divisions: int) -> list[float]:
    if divisions < 2:
        raise OptimizationInputError("phase_divisions ต้องไม่น้อยกว่า 2")
    return [k / divisions for k in range(divisions)]


def search_lattice(usable, field_bounds, spec: LatticeSpec,
                   angle_step_deg: float = 2.0,
                   phase_divisions: int = 10,
                   refine: bool = False,
                   refine_angle_step_deg: float = 0.25,
                   refine_phase_divisions: int = 4,
                   top_k: int = 10) -> dict[str, Any]:
    """Exhaustively enumerate the requested finite angle/phase grid.

    Optional local refinement is itself fully enumerated and is included in
    the declared candidate set. It does not imply continuous optimality.
    """
    if not (0 < angle_step_deg <= spec.angle_period_deg):
        raise OptimizationInputError("angle_step_deg ไม่อยู่ในช่วงที่ถูกต้อง")
    phases = _phase_values(phase_divisions)
    angle_count = int(math.ceil(spec.angle_period_deg / angle_step_deg - 1e-12))
    angles = [min(k * angle_step_deg, spec.angle_period_deg - 1e-10)
              for k in range(angle_count)]
    started = time.perf_counter()
    best = None
    scored: list[tuple[int, float, float, float]] = []
    evaluated = 0

    def evaluate(theta, pa, pb):
        nonlocal best, evaluated
        item = enumerate_layout(usable, field_bounds, spec, theta, pa, pb, False)
        evaluated += 1
        score = (item["count"], -theta, -pa, -pb)
        scored.append((item["count"], theta % spec.angle_period_deg, pa % 1.0, pb % 1.0))
        if best is None or score > best[0]:
            best = (score, item)

    for theta in angles:
        for pa in phases:
            for pb in phases:
                evaluate(theta, pa, pb)

    coarse_best = best[1]
    refinement_evaluated = 0
    if refine:
        angle_offsets = np.arange(
            -angle_step_deg, angle_step_deg + refine_angle_step_deg * 0.5,
            refine_angle_step_deg
        )
        phase_delta = 1.0 / phase_divisions
        fine_step = phase_delta / refine_phase_divisions
        offsets = np.arange(-phase_delta, phase_delta + fine_step * 0.5, fine_step)
        seen = set()
        for dt in angle_offsets:
            theta = (coarse_best["theta_deg"] + dt) % spec.angle_period_deg
            for da in offsets:
                pa = (coarse_best["phase_a"] + da) % 1.0
                for db in offsets:
                    pb = (coarse_best["phase_b"] + db) % 1.0
                    key = (round(theta, 9), round(pa, 9), round(pb, 9))
                    if key in seen:
                        continue
                    seen.add(key)
                    evaluate(theta, pa, pb)
                    refinement_evaluated += 1

    assert best is not None
    best_layout = enumerate_layout(
        usable, field_bounds, spec, best[1]["theta_deg"],
        best[1]["phase_a"], best[1]["phase_b"], include_points=True
    )
    evaluated += 1  # final point regeneration is a deterministic evaluation
    elapsed = time.perf_counter() - started
    unique_scored = sorted(set(scored), key=lambda x: (-x[0], x[1], x[2], x[3]))
    return {
        "spec": spec,
        "best": best_layout,
        "best_count": best_layout["count"],
        "best_theta_deg": best_layout["theta_deg"],
        "best_phase_a": best_layout["phase_a"],
        "best_phase_b": best_layout["phase_b"],
        "coarse_best_count": coarse_best["count"],
        "evaluated_layouts": evaluated,
        "coarse_layouts": len(angles) * phase_divisions * phase_divisions,
        "refinement_layouts": refinement_evaluated,
        "angle_step_deg": angle_step_deg,
        "phase_divisions": phase_divisions,
        "refine_enabled": refine,
        "top_results": [
            {"count": n, "theta_deg": t, "phase_a": pa, "phase_b": pb}
            for n, t, pa, pb in unique_scored[:top_k]
        ],
        "elapsed_seconds": elapsed,
    }


def _conservative_buffer_radius(distance: float, quad_segs: int) -> float:
    if distance <= 0:
        return 0.0
    return distance / math.cos(math.pi / (4.0 * quad_segs))


def lattice_upper_bound(usable, spec: LatticeSpec, quad_segs: int = 128) -> dict[str, Any]:
    """A conservative area bound for all translations/orientations of a lattice.

    A centered fundamental parallelogram around each accepted lattice point has
    area `cell_area`; these cells tile the plane and lie within a radius-R disk
    around their lattice point. Thus N*cell_area <= area(U buffered by R).
    The polygonal buffer radius is inflated so its chords conservatively contain
    the ideal radius-R disk. This is a valid but generally loose bound for the
    specified lattice family, not for arbitrary unconstrained point placement.
    """
    if usable.is_empty:
        return {"expanded_area_m2": 0.0, "cell_area_m2": spec.cell_area,
                "upper_bound_count": 0, "circumradius_m": spec.circumradius}
    r = _conservative_buffer_radius(spec.circumradius, quad_segs)
    expanded = usable.buffer(r, quad_segs=quad_segs, join_style="round")
    expanded_area = float(expanded.area)
    quotient = expanded_area / spec.cell_area
    # ceil is intentionally conservative under floating point round-off.
    upper = int(math.ceil(quotient - 1e-12))
    return {
        "expanded_area_m2": expanded_area,
        "cell_area_m2": spec.cell_area,
        "upper_bound_count": upper,
        "circumradius_m": spec.circumradius,
        "buffer_radius_used_m": r,
        "bound_method": "fundamental-cell area bound using a circumscribed disk",
    }


def _make_points(best: dict[str, Any], plants_per_hole: int) -> list[dict[str, Any]]:
    output = []
    order = sorted(range(best["count"]), key=lambda idx: (int(best["accepted_i"][idx]), int(best["accepted_j"][idx])))
    for n, idx in enumerate(order, start=1):
        output.append({
            "plant_id": f"V04-P{n:04d}",
            "lattice_i": int(best["accepted_i"][idx]),
            "lattice_j": int(best["accepted_j"][idx]),
            "x_m": round(float(best["accepted_x"][idx]), 9),
            "y_m": round(float(best["accepted_y"][idx]), 9),
            "plants_in_hole": plants_per_hole,
        })
    return output


def run_benchmarks(case: dict[str, Any], *, angle_step_deg: float = 2.0,
                   phase_divisions: int = 10, refine: bool = True,
                   run_comparison_lattices: bool = True) -> dict[str, Any]:
    v02 = compute_usable_area(case)
    result02 = v02["result"]
    usable = v02["geometries"]["usable"]
    # Prepare the static polygon once; vectorized covers is much faster in repeated searches.
    shapely.prepare(usable)
    field = v02["geometries"]["field"]
    crop = case.get("crop", {})
    row_spacing = float(crop.get("row_spacing_m", 0.75))
    in_row_spacing = float(crop.get("in_row_spacing_m", 0.25))
    plants_per_hole = int(crop.get("plants_per_hole_after_thinning", 1))
    if row_spacing <= 0 or in_row_spacing <= 0 or plants_per_hole <= 0:
        raise OptimizationInputError("ข้อมูลระยะปลูกและจำนวนต้นต่อหลุมต้องเป็นค่าบวก")
    specs = _make_specs(row_spacing, in_row_spacing)

    # V0.3 baseline: x=0.50 + j*0.25, y=0.50 + i*0.75.
    # In the canonical rectangular basis, this corresponds to phase fractions 0 and 2/3.
    fixed_phase = enumerate_layout(
        usable, field.bounds, specs["rectangular_crop"], 0.0, 0.0,
        (0.5 % row_spacing) / row_spacing, include_points=True
    )
    fixed_points = _make_points(fixed_phase, plants_per_hole)

    area = float(usable.area)
    area_estimate = area / (row_spacing * in_row_spacing)
    rectangular_search = search_lattice(
        usable, field.bounds, specs["rectangular_crop"], angle_step_deg,
        phase_divisions, refine=refine
    )
    rectangular_bound = lattice_upper_bound(usable, specs["rectangular_crop"])
    rectangular_gap = max(0.0, (rectangular_bound["upper_bound_count"] - rectangular_search["best_count"]) / rectangular_bound["upper_bound_count"]) if rectangular_bound["upper_bound_count"] else 0.0

    methods = [
        {
            "method": "Area-per-plant estimate",
            "category": "density_estimate_only",
            "count": area_estimate,
            "integer_estimate_floor": math.floor(area_estimate),
            "nominal_cell_area_m2": row_spacing * in_row_spacing,
            "agronomically_row_feasible": None,
            "note": "ค่าประมาณจากพื้นที่หารพื้นที่ต่อหลุม ไม่ใช่ชุดพิกัดที่จัดวางได้ และไม่ใช่ upper bound",
        },
        {
            "method": "V0.3 fixed rectangular grid",
            "category": "feasible_fixed_layout",
            "count": fixed_phase["count"],
            "theta_deg": 0.0,
            "phase_a_fraction": 0.0,
            "phase_b_fraction": (0.5 % row_spacing) / row_spacing,
            "agronomically_row_feasible": True,
            "note": "แนวแถวขนานแกน X และ anchor เดิม (0.50, 0.50) เมตร",
        },
        {
            "method": "Optimized rectangular crop-row lattice",
            "category": "crop_row_lattice",
            "count": rectangular_search["best_count"],
            "theta_deg": rectangular_search["best_theta_deg"],
            "phase_a_fraction": rectangular_search["best_phase_a"],
            "phase_b_fraction": rectangular_search["best_phase_b"],
            "agronomically_row_feasible": True,
            "note": "ค้นหาทิศทางและ phase ภายในชุดพารามิเตอร์ที่แจกแจงไว้; ยังไม่ใช่การจัดวางอิสระทุกรูปแบบ",
        },
    ]

    comparison_searches = {}
    if run_comparison_lattices:
        for key in ("square_equal_density", "triangular_equal_density"):
            comparison_searches[key] = search_lattice(
                usable, field.bounds, specs[key], angle_step_deg,
                phase_divisions, refine=refine
            )
            methods.append({
                "method": specs[key].name,
                "category": "geometry_only_equal_density_benchmark",
                "count": comparison_searches[key]["best_count"],
                "theta_deg": comparison_searches[key]["best_theta_deg"],
                "phase_a_fraction": comparison_searches[key]["best_phase_a"],
                "phase_b_fraction": comparison_searches[key]["best_phase_b"],
                "agronomically_row_feasible": False,
                "note": "ปรับ cell area ให้เท่ากับระยะปลูก 0.25×0.75 ม. เพื่อเทียบรูปทรง lattice; ไม่รักษาเงื่อนไขแถวข้าวโพด 0.75 ม. จึงเป็น benchmark เชิงเรขาคณิต ไม่ใช่แผนปลูกที่แนะนำ",
            })

    upper_bounds = {
        "rectangular_crop_row_lattice": rectangular_bound,
    }
    for key, search in comparison_searches.items():
        upper_bounds[key] = lattice_upper_bound(usable, specs[key])
        ub = upper_bounds[key]["upper_bound_count"]
        search["upper_bound"] = ub
        search["relative_gap"] = max(0.0, (ub - search["best_count"]) / ub) if ub else 0.0
        search["proven_optimal_over_continuous_lattice_family"] = search["best_count"] >= ub

    points = _make_points(rectangular_search["best"], plants_per_hole)
    output = {
        "project": "PROUVÉ Spatial",
        "version": "0.4",
        "use_case": "PS-FU01",
        "coordinate_system": "Local planar XY; metres (not geographic coordinates)",
        "input": {
            "row_spacing_m": row_spacing,
            "in_row_spacing_m": in_row_spacing,
            "plants_per_hole_after_thinning": plants_per_hole,
            "usable_area_m2": area,
            "field_area_m2": float(field.area),
            "boundary_setback_m": result02["parameters"]["boundary_setback_m"],
            "obstacle_buffer_m": result02["parameters"]["obstacle_buffer_m"],
        },
        "benchmark_methods": methods,
        "search": {
            "rectangular_crop_row": {
                "best_count": rectangular_search["best_count"],
                "best_theta_deg": rectangular_search["best_theta_deg"],
                "best_phase_a_fraction": rectangular_search["best_phase_a"],
                "best_phase_b_fraction": rectangular_search["best_phase_b"],
                "evaluated_layouts": rectangular_search["evaluated_layouts"],
                "coarse_layouts": rectangular_search["coarse_layouts"],
                "refinement_layouts": rectangular_search["refinement_layouts"],
                "angle_step_deg": angle_step_deg,
                "phase_divisions": phase_divisions,
                "upper_bound_count": rectangular_bound["upper_bound_count"],
                "relative_gap_to_upper_bound": rectangular_gap,
                "best_over_enumerated_search_grid_proven": True,
                "continuous_lattice_optimum_proven": rectangular_search["best_count"] >= rectangular_bound["upper_bound_count"],
                "top_results": rectangular_search["top_results"],
                "elapsed_seconds": rectangular_search["elapsed_seconds"],
            },
            "comparison_lattices": {
                key: {
                    "best_count": srch["best_count"],
                    "best_theta_deg": srch["best_theta_deg"],
                    "best_phase_a_fraction": srch["best_phase_a"],
                    "best_phase_b_fraction": srch["best_phase_b"],
                    "evaluated_layouts": srch["evaluated_layouts"],
                    "upper_bound_count": srch["upper_bound"],
                    "relative_gap_to_upper_bound": srch["relative_gap"],
                    "best_over_enumerated_search_grid_proven": True,
                    "continuous_lattice_optimum_proven": srch["proven_optimal_over_continuous_lattice_family"],
                    "elapsed_seconds": srch["elapsed_seconds"],
                } for key, srch in comparison_searches.items()
            },
        },
        "optimality_evidence": {
            "rectangular_lattice_upper_bound": rectangular_bound,
            "interpretation": "ขอบเขตบนจากพื้นที่ของ fundamental cells ภายในการขยายพื้นที่ปลูกด้วยรัศมีครอบคลุม cell; ใช้กับ lattice family ที่ระบุเท่านั้น ไม่ใช่ upper bound สำหรับการจัดวางจุดอิสระทั่วไป",
            "relative_gap_definition": "(upper_bound_count - best_found_count) / upper_bound_count",
            "rectangular_relative_gap": rectangular_gap,
            "best_found_count": rectangular_search["best_count"],
            "upper_bound_count": rectangular_bound["upper_bound_count"],
            "continuous_lattice_optimum_proven": rectangular_search["best_count"] >= rectangular_bound["upper_bound_count"],
        },
        "verification": {
            "independent_verifier_required": True,
            "generated_points": len(points),
            "point_export": "optimized_planting_positions.csv",
            "status_before_independent_verification": "PENDING",
        },
        "limitations": [
            "Best found is exact only over the explicitly enumerated finite angle/phase search grid.",
            "Refinement searches a finite local grid around the coarse winner; it is not a continuous search proof.",
            "The geometric upper bound applies only to the specified lattice family, not arbitrary free point placements.",
            "Square and triangular grids are equal-nominal-density geometric benchmarks; they do not preserve the 0.75 m crop row-spacing rule and are not agronomic recommendations.",
            "Area-per-plant is a density estimate, not a feasible point placement or upper bound.",
            "Coordinates and PS-FU01 field are synthetic local XY test data, not a surveyed farm boundary.",
            "The model covers planting-hole centres and geometric clearances only; it does not establish crop health, yield, root competition, irrigation access, or machinery access.",
        ],
        "planting_positions": points,
    }
    return {"result": output, "v02": v02}


def export_csv(points: list[dict[str, Any]], path: Path) -> None:
    fields = ["plant_id", "lattice_i", "lattice_j", "x_m", "y_m", "plants_in_hole"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(points)


def export_benchmarks_csv(methods: list[dict[str, Any]], path: Path) -> None:
    fields = ["method", "category", "count", "theta_deg", "phase_a_fraction",
              "phase_b_fraction", "agronomically_row_feasible", "note"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in methods:
            writer.writerow({k: row.get(k) for k in fields})


def main() -> int:
    parser = argparse.ArgumentParser(description="PROUVE Spatial V0.4 optimization and research validation")
    parser.add_argument("case", nargs="?", default="PS-FU01_V03.json")
    parser.add_argument("--output", default="v04_output.json")
    parser.add_argument("--positions", default="optimized_planting_positions.csv")
    parser.add_argument("--benchmarks", default="benchmark_results.csv")
    parser.add_argument("--angle-step", type=float, default=2.0)
    parser.add_argument("--phase-divisions", type=int, default=10)
    parser.add_argument("--no-refine", action="store_true")
    parser.add_argument("--no-comparison-lattices", action="store_true")
    args = parser.parse_args()
    case = json.loads(Path(args.case).read_text(encoding="utf-8"))
    computed = run_benchmarks(case, angle_step_deg=args.angle_step,
                              phase_divisions=args.phase_divisions,
                              refine=not args.no_refine,
                              run_comparison_lattices=not args.no_comparison_lattices)
    result = computed["result"]
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    export_csv(result["planting_positions"], Path(args.positions))
    export_benchmarks_csv(result["benchmark_methods"], Path(args.benchmarks))
    print(json.dumps({
        "methods": [{"method": m["method"], "count": m["count"]} for m in result["benchmark_methods"]],
        "rectangular_search": result["search"]["rectangular_crop_row"],
        "optimality_evidence": result["optimality_evidence"],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
