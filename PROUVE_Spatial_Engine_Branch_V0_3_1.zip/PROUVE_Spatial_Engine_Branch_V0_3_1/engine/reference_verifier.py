"""Shapely-free numerical reference verifier for rectangular-lattice plans.

Scope: simple, hole-free polygon rings and rectangular crop-row lattice only.
This is an independent implementation candidate, not an exact-geometry proof.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

TOL = 1e-7


class ReferenceVerificationError(ValueError):
    pass


def _number(value: Any, label: str, *, minimum: float | None = None) -> float:
    if isinstance(value, bool):
        raise ReferenceVerificationError(f"{label}: boolean is not a numeric value")
    try:
        out = float(value)
    except (TypeError, ValueError) as exc:
        raise ReferenceVerificationError(f"{label}: numeric value required") from exc
    if not math.isfinite(out):
        raise ReferenceVerificationError(f"{label}: finite value required")
    if minimum is not None and out < minimum:
        raise ReferenceVerificationError(f"{label}: value below minimum {minimum}")
    return out


def _integer(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ReferenceVerificationError(f"{label}: integer required")
    return value


def _finite_pair(p: Any) -> bool:
    return (isinstance(p, (list, tuple)) and len(p) == 2 and
            all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v)) for v in p))


def _point_segment_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    den = dx*dx + dy*dy
    if den == 0:
        return math.hypot(p[0]-a[0], p[1]-a[1])
    t = max(0.0, min(1.0, ((p[0]-a[0])*dx + (p[1]-a[1])*dy)/den))
    return math.hypot(p[0]-(a[0]+t*dx), p[1]-(a[1]+t*dy))


def _ring_edges(ring):
    return list(zip(ring, ring[1:] + ring[:1]))


def _point_on_boundary(p, ring, tol=TOL):
    return any(_point_segment_distance(p, a, b) <= tol for a, b in _ring_edges(ring))


def _inside_or_boundary(p, ring):
    if _point_on_boundary(p, ring):
        return True
    x, y = p
    inside = False
    for (x1, y1), (x2, y2) in _ring_edges(ring):
        if (y1 > y) != (y2 > y):
            xin = x1 + (y-y1)*(x2-x1)/(y2-y1)
            if x < xin:
                inside = not inside
    return inside


def _strictly_inside(p, ring):
    if _point_on_boundary(p, ring):
        return False
    x, y = p
    inside = False
    for (x1, y1), (x2, y2) in _ring_edges(ring):
        if (y1 > y) != (y2 > y):
            xin = x1 + (y-y1)*(x2-x1)/(y2-y1)
            if x < xin:
                inside = not inside
    return inside


def _boundary_distance(p, ring):
    return min(_point_segment_distance(p, a, b) for a, b in _ring_edges(ring))


def _orient(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def _on_segment(a, b, p):
    return (min(a[0], b[0])-TOL <= p[0] <= max(a[0], b[0])+TOL and
            min(a[1], b[1])-TOL <= p[1] <= max(a[1], b[1])+TOL and
            abs(_orient(a, b, p)) <= TOL)


def _segments_intersect(a, b, c, d):
    o1, o2, o3, o4 = _orient(a,b,c), _orient(a,b,d), _orient(c,d,a), _orient(c,d,b)
    if ((o1 > TOL and o2 < -TOL) or (o1 < -TOL and o2 > TOL)) and ((o3 > TOL and o4 < -TOL) or (o3 < -TOL and o4 > TOL)):
        return True
    return ((abs(o1) <= TOL and _on_segment(a,b,c)) or
            (abs(o2) <= TOL and _on_segment(a,b,d)) or
            (abs(o3) <= TOL and _on_segment(c,d,a)) or
            (abs(o4) <= TOL and _on_segment(c,d,b)))


def _valid_ring(ring: Any, label: str):
    if not isinstance(ring, list) or len(ring) < 3 or not all(_finite_pair(p) for p in ring):
        raise ReferenceVerificationError(f"{label}: invalid coordinate ring")
    clean = [tuple(map(float, p)) for p in ring]
    if len(clean) >= 4 and clean[0] == clean[-1]:
        clean = clean[:-1]
    if len(clean) < 3 or len(set(clean)) < 3:
        raise ReferenceVerificationError(f"{label}: fewer than three distinct vertices")
    if any(math.dist(clean[k], clean[(k+1)%len(clean)]) <= TOL for k in range(len(clean))):
        raise ReferenceVerificationError(f"{label}: zero-length edge")
    n = len(clean)
    for i in range(n):
        a, b = clean[i], clean[(i+1)%n]
        for j in range(i+1, n):
            if j == i or j == (i+1)%n or (j+1)%n == i:
                continue
            if _segments_intersect(a, b, clean[j], clean[(j+1)%n]):
                raise ReferenceVerificationError(f"{label}: self-intersecting polygon")
    # Translate to the first vertex before the shoelace sum to reduce
    # cancellation when projected coordinates have large absolute offsets.
    ox, oy = clean[0]
    shifted = [(x-ox, y-oy) for x, y in clean]
    signed = sum(shifted[i][0]*shifted[(i+1)%n][1] - shifted[(i+1)%n][0]*shifted[i][1]
                 for i in range(n))/2
    if abs(signed) <= TOL:
        raise ReferenceVerificationError(f"{label}: zero area")
    return clean


def verify_plan_reference(case: dict, result: dict):
    """Verify feasibility independently of Shapely/GEOS and optimizer code."""
    if not isinstance(case, dict) or not isinstance(result, dict):
        raise ReferenceVerificationError("case and result must be objects")
    field_spec = case.get("field")
    if not isinstance(field_spec, dict):
        raise ReferenceVerificationError("field must be an object")
    field = _valid_ring(field_spec.get("vertices"), "field")
    obstacle_specs = case.get("obstacles", [])
    if not isinstance(obstacle_specs, list):
        raise ReferenceVerificationError("obstacles must be a list")
    obstacles = []
    for idx, spec in enumerate(obstacle_specs, start=1):
        if not isinstance(spec, dict):
            raise ReferenceVerificationError(f"obstacles[{idx}] must be an object")
        ring = _valid_ring(spec.get("vertices"), spec.get("name", f"obstacle-{idx}"))
        # Obstacle polygon containment is validated by Geometry Engine before
        # this point-level reference check. This verifier checks that proposed
        # stations do not enter or violate clearance to each supplied obstacle.
        obstacles.append(ring)

    settings = case.get("settings", {})
    crop = case.get("crop", {})
    if not isinstance(settings, dict) or not isinstance(crop, dict):
        raise ReferenceVerificationError("settings and crop must be objects")
    setback = _number(settings.get("boundary_setback_m", 0.0), "boundary_setback_m", minimum=0)
    obstacle_clearance = _number(settings.get("obstacle_buffer_m", 0.0), "obstacle_buffer_m", minimum=0)
    row = _number(crop.get("row_spacing_m", 0.75), "row_spacing_m", minimum=1e-15)
    along = _number(crop.get("in_row_spacing_m", 0.25), "in_row_spacing_m", minimum=1e-15)

    search = result.get("search")
    if not isinstance(search, dict) or not isinstance(search.get("rectangular_crop_row"), dict):
        raise ReferenceVerificationError("missing rectangular_crop_row search metadata")
    layout = search["rectangular_crop_row"]
    theta_deg = _number(layout.get("best_theta_deg"), "best_theta_deg")
    pa = _number(layout.get("best_phase_a_fraction"), "best_phase_a_fraction")
    pb = _number(layout.get("best_phase_b_fraction"), "best_phase_b_fraction")
    if not (0.0 <= pa < 1.0 and 0.0 <= pb < 1.0):
        raise ReferenceVerificationError("phase fractions must be in [0,1)")

    points = result.get("planting_positions")
    if not isinstance(points, list) or len(points) == 0:
        return {"verifier": "python_reference_no_shapely_v2", "implementation_independent_of_optimizer": True,
                "all_checks_passed": False, "verified_point_count": 0,
                "status": "NO_FEASIBLE_POINTS", "reason": "EMPTY_PLAN_NOT_ELIGIBLE_FOR_VERIFICATION"}

    declared_count = layout.get("best_count")
    if declared_count is not None and _integer(declared_count, "best_count") != len(points):
        raise ReferenceVerificationError("planting_positions count differs from declared best_count")

    t = math.radians(theta_deg)
    ax, ay = along*math.cos(t), along*math.sin(t)
    bx, by = -row*math.sin(t), row*math.cos(t)
    failures = {k: 0 for k in ("outside_field", "boundary_clearance", "obstacle_clearance",
                               "coordinate_reconstruction", "duplicate_lattice_indices",
                               "duplicate_coordinates", "row_spacing", "in_row_spacing")}
    seen = set(); seen_coords = set(); rows = defaultdict(list)
    min_boundary = math.inf; min_obstacle = math.inf
    for index, entry in enumerate(points, start=1):
        if not isinstance(entry, dict):
            failures["coordinate_reconstruction"] += 1
            continue
        try:
            x = _number(entry.get("x_m"), f"planting_positions[{index}].x_m")
            y = _number(entry.get("y_m"), f"planting_positions[{index}].y_m")
            i = _integer(entry.get("lattice_i"), f"planting_positions[{index}].lattice_i")
            j = _integer(entry.get("lattice_j"), f"planting_positions[{index}].lattice_j")
        except ReferenceVerificationError:
            failures["coordinate_reconstruction"] += 1
            continue
        if (i, j) in seen:
            failures["duplicate_lattice_indices"] += 1
        seen.add((i, j)); rows[i].append((j, x, y))
        ckey = (round(x, 9), round(y, 9))
        if ckey in seen_coords:
            failures["duplicate_coordinates"] += 1
        seen_coords.add(ckey)
        p = (x, y)
        if not _inside_or_boundary(p, field):
            failures["outside_field"] += 1
        db = _boundary_distance(p, field); min_boundary = min(min_boundary, db)
        if db < setback - TOL:
            failures["boundary_clearance"] += 1
        for obs in obstacles:
            inside = _strictly_inside(p, obs)
            do = _boundary_distance(p, obs)
            min_obstacle = min(min_obstacle, do)
            if inside or do < obstacle_clearance - TOL:
                failures["obstacle_clearance"] += 1
                break
        xr = (pa+j)*ax + (pb+i)*bx
        yr = (pa+j)*ay + (pb+i)*by
        if math.hypot(x-xr, y-yr) > 2e-8:
            failures["coordinate_reconstruction"] += 1

    row_keys = sorted(rows)
    for i, entries in rows.items():
        entries.sort()
        for left, right in zip(entries, entries[1:]):
            if (right[0]-left[0])*along < along-TOL:
                failures["in_row_spacing"] += 1
    for pos, i in enumerate(row_keys):
        for j in row_keys[pos+1:]:
            if (j-i)*row < row-TOL:
                failures["row_spacing"] += 1

    passed = all(v == 0 for v in failures.values())
    return {"verifier": "python_reference_no_shapely_v2",
            "implementation_independent_of_optimizer": True,
            "checks": failures, "all_checks_passed": passed,
            "verified_point_count": len(points),
            "minimum_boundary_clearance_m": min_boundary,
            "minimum_obstacle_clearance_m": None if not obstacles else min_obstacle,
            "required_boundary_setback_m": setback,
            "required_obstacle_clearance_m": obstacle_clearance,
            "status": "VERIFIED_FEASIBLE" if passed else "VERIFICATION_FAILED",
            "scope": "Numerical cross-check independent of Shapely/GEOS for simple hole-free rings and rectangular lattices; assumes Geometry Engine prevalidated obstacle containment; not exact arithmetic or external audit."}
